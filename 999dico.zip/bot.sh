       #tele x 30 akun pertama
       python 999dice.py sleep 2 
       python 999dice.py sleep 2 
       python 999dice.py sleep 2 
       python 999dice.py sleep 2 
       python 999dice.py sleep 2 
       python 999dice.py sleep 2 
       
       sh bot.sh
